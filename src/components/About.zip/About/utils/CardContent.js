
const Trailblazers = [

    {
        id: 1,
        img: "images/blazers-1.webp",
        name: "RONNIE SCREWVALA",
        designation: 'Co-Founder and Chairman',
        title: "One of the '25 Asia’s Most Powerful People,' by Fortune Magazine"

    },
    {
        id: 2,
        img: "images/blazers-2.webp",
        name: "RONNIE SCREWVALA",
        designation: 'Co-Founder and Chairman',
        title: "One of the '25 Asia’s Most Powerful People,' by Fortune Magazine"
    },
    {
        id: 3,
        img: "images/blazers-3.webp",
        name: "RONNIE SCREWVALA",
        designation: 'Co-Founder and Chairman',
        title: "One of the '25 Asia’s Most Powerful People,' by Fortune Magazine"

    },

]

const Team = [

    {
        id: 1,
        img: "images/ceo.jpg",
        name: "MYLEETA AGE WILLIAMS",
        designation: 'CEO International',

    },
    {
        id: 2,
        img: "images/manager.jpg",
        name: "RONNIE SCREWVALA",
        designation: 'CEO International',
    }
    ,
    {
        id: 3,
        img: "images/cto.jpg",
        name: "RONNIE SCREWVALA",
        designation: 'CEO International',

    },
    {
        id: 4,
        img: "images/accountant.jpg",
        name: "RONNIE SCREWVALA",
        designation: 'CEO International',

    }, {
        id: 5,
        img: "images/cto.jpg",
        name: "RONNIE SCREWVALA",
        designation: 'CEO International',

    }, {
        id: 6,
        img: "images/accountant.jpg",
        name: "RONNIE SCREWVALA",
        designation: 'CEO International',

    }, {
        id: 7,
        img: "images/manager.jpg",
        name: "RONNIE SCREWVALA",
        designation: 'CEO International',

    },
    {
        id: 8,
        img: "images/ceo.jpg",
        name: "RONNIE SCREWVALA",
        designation: 'CEO International',

    },

]


const Partners = [

    {
        id: 1,
        img: "images/expanding-1.webp",
        title:"Recruitment and Staffing", 
        title2:"for enterprises"
    },
    {
        id: 2,
        img: "images/expanding-2.webp",
        title: "Test Preparation for",
        title2:" fresh graduates"

    },

    {
        id: 3,
        img: "images/expanding-1.webp",
        title: "Blended campus for",
        title2: "college students"
    }, 
    {
        id: 4,
        img: "images/expanding-2.webp",
        title:"A Global EdTech company with", 
        title2:"presence in 70+ countries"

    },

]
const Growth=[
{
    id: 1,
    img: "images/growth-icn-1.webp",
    title:"Entered the Unicorn Club",
    content:"Raised funding from IFC, IIFL & Teamsek and"

},
{
    id: 2,
    img: "images/growth-icn-2.webp",
    title:"Entered the Unicorn Club",
    content:"Raised funding from IFC, IIFL & Teamsek and"

},{
    id: 3,
    img: "images/growth-icn-3.webp",
    title:"Entered the Unicorn Club",
    content:"Raised funding from IFC, IIFL & Teamsek and"

},{
    id: 4,
    img: "images/growth-icn-4.webp",
    title:"Entered the Unicorn Club",
    content:"Raised funding from IFC, IIFL & Teamsek and"

},


]





export {Team, Trailblazers, Partners,Growth}